import matplotlib.pylab as plt
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

lin = lambda x,a,b: a*x +b


def plot_it():

    #fr_range = [16.25,15.3,14.37,13.36,12.49]
        df = pd.read_excel("zeeman.xlsx",sheet_name='Sheet1')
        df=df.dropna(subset=['B','Dk'])
        print(df)
        b = np.array(df['B'].tolist())
        dk=np.array(df['Dk'].tolist())
    #pointers = ['^','o','d','P','*']
    #colors = ['#F57C12','#143C24','#031521','#CA4286','#607E4D']
    
        plt.plot(b, dk,c='red',marker='^',ls='',label='Data points')
        pov,pocv = curve_fit(lin,b,dk)
        plt.xlabel("B(mT)")
        plt.ylabel("$\Delta k$(1/nm)")
        plt.plot(b,lin(b,*pov),color='#143C24',ls='--',label='Fit')
        plt.title('$\Delta k\ vs\ B $')
        text = "Slope = %0.3e +/- %0.3e\nIntercept = %0.3e +/- %0.3e"%(pov[0],pocv[0][0]**0.5,pov[1],pocv[1][1]**0.5)
        plt.text(450,0.04,text)
        plt.grid()
        plt.legend()
        plt.savefig("plot.png")
        plt.show()
        #plt.clf()
plot_it()
